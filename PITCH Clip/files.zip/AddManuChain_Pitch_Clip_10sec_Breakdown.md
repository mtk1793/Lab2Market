# AddManuChain – 90-Second Pitch Clip
## 10-Second Segment Breakdown

---

## **SEGMENT 1: :00–:10 | CALM OPERATIONS + SUDDEN FAILURE**

### Narrative
Clear Arctic industrial site. Equipment runs flawlessly. Operator stands confident. At second 6, catastrophic failure strikes — alarms, violence, crisis begins. Operator doesn't panic.

### Visuals
- **Background:** Bright daylight, clear sky, snow-capped mountains, fluffy clouds
- **Equipment:** Rotating smoothly, green operational lights, calm status display
- **Operator:** Standing confidently, slight smile, glowing pocket (digital inventory hint)
- **At 6s:** Camera shake, equipment gear stops abruptly, status turns red, display reads "!! FAILURE !!"
- **Smoke & cracks:** Begin emerging from equipment

### Audio
- **0–6s:** Peaceful ambient synth (C major, 20% volume), subtle machinery hum
- **6s:** 3x rapid beeps (800Hz alarm), metallic thud, impact sound
- **6.5–10s:** Tension strings layer in, equipment rattle, low rumble

### Key Metric
- **Downtime timer starts:** 00:00
- **Loss counter:** $0 (stays green)

### Emotional Arc
Confidence → Shock → Calm determination

---

## **SEGMENT 2: :10–:20 | HERO RETRIEVAL + PERFECT INSTALLATION + VICTORY**

### Narrative
Operator reaches into pocket, retrieves glowing 3D-printed part. Part floats with epic particle trail toward equipment and snaps into place. Equipment roars back to life. Victory.

### Visuals
- **Camera:** Wide shot, slow pull-back to reveal victory
- **Operator:** Retrieves part from glowing pocket (1.5s), holds aloft confidently (3–5s), gives thumbs-up at victory (7–10s)
- **Floating Part:** Cyan glow, dramatic pulsing spotlight effect, particle trail
- **Installation:** Guide lines appear (5–5.5s), white flash, spark explosion on snap (5.5s)
- **Equipment Recovery:**
  - 5.5–6s: Status light red → yellow, display "INITIALIZING..."
  - 6–6.5s: Status light yellow → green, display "OPERATIONAL", gear accelerates to full speed
  - Cracks fade out, smoke stops, equipment pristine again
- **Victory:** Confetti (80 pieces, 2.5–3.5s lifetime), golden hour lighting added

### Audio
- **0–3s:** Ambient continues
- **3–5s:** Tracking motion, anticipatory tension
- **5.5s:** Satisfying metallic SNAP (3-part harmonic clang: 200/1800/3200Hz)
- **5.5–6.5s:** Triumphant synth chord (C5–E5–G5–C6 sequence, sine wave)
- **7–10s:** Celebratory ambient, confetti audio texture

### Key Metrics
- **Downtime timer stops:** 00:15
- **Production loss:** $0 (green checkmark)
- **Message:** ✅ MISSION-CRITICAL SYSTEMS MAINTAINED

### Emotional Arc
Focused action → Installation tension → Triumph & celebration

---

## **SEGMENT 3: :20–:30 | TRANSITION + SCENARIO B SETUP + FAILURE**

### Narrative
Fade to black. "But what if you didn't have digital inventory?" Camera opens on SAME location, SAME equipment — but NO digital solution. Physical storage 200m away. Storm clouds gather. Equipment fails identically. Operator looks toward storage with dread.

### Visuals
- **Transition:** 2s fade to black + ominous text on black, then fade in
- **Background:** Same Arctic site but MOODIER — desaturated, cooler colors, storm clouds on horizon creeping in
- **Equipment:** Runs normally until 6s, then identical violent failure (but shake is HARDER: intensity 1.2 vs 1.0)
- **New element:** Storage unit visible at 72% screen right (small weathered shed with spare parts on shelves)
- **Distance marker:** Eventually shows "← 200m →"
- **Operator:** No pocket glow this time, watches sky nervously, then looks toward storage with DREAD after failure

### Audio
- **0–2s:** Fade to silence
- **2.5s:** Low D minor drone begins (ominous, 10% volume)
- **4s:** Distant wind whisper
- **6s:** Harsher alarm (400Hz sawtooth, lower pitch than Scenario A, 3 beeps 220ms apart)
- **8s:** Wind sounds begin building

### Key Metrics
- **Downtime timer starts:** 6s (red)
- **Loss counter:** Jumps at 7s to $10,000 (red)
- **Alert:** ⚠️ CRITICAL FAILURE – Impeller X DAMAGED

### Emotional Arc
Reset & warning → Rising dread → realization of distance & danger

---

## **SEGMENT 4: :30–:40 | STORM HITS + DESPERATE WALK BEGINS**

### Narrative
Weather deteriorates RAPIDLY. Rain, wind, -25°C. Operator begins the 200-meter trek toward storage. Fighting howling wind. Temperature drops to -34°C by end. They stumble once from powerful gust. Loss counter climbs to $45,000.

### Visuals
- **Weather progression:**
  - Rain rate: 16 → 56 particles/sec (line-based drops)
  - Snow rate: 2 → 5 particles/sec
  - Wind speed: 40 → 80 km/h
  - Temperature display: -15°C → -25°C
  - Fog opacity: 0 → 0.08
  - Sky darkening: from bright to #3a4a5a
  - Frost creeping in from screen edges
- **Operator movement:** Walks from 28% to 48% screen (labored, struggling)
  - Walk animation dampened by wind
  - Body leans into wind
  - Shivering increases (3x-visible oscillation)
  - Cold breath puffs visible
- **Stumble at 6.5s:**
  - High-frequency wobble (15Hz)
  - Screen shake 0.4
  - Audio whoosh + grunt
- **Wind visual streaks:** Long horizontal particles at 500+px/s

### Audio
- **Continuous:** Howling wind (4% → 8%), rain patter (increasing), dark ambient drone (D minor)
- **6.5s:** Sharp wind gust whoosh, operator grunt
- **8.5s:** Distant thunder rumble (55Hz 1.2s)

### Key Metrics
- **Downtime timer:** Counts real-time (6x speed acceleration later)
- **Loss counter:** $15,000 → $45,000 (smooth climb, flash at -$15,000 / -$10,000)
- **Temperature display:** Now showing on HUD
- **Wind speed display:** Now showing on HUD

### Emotional Arc
Initial optimism → growing dread → physical struggle → desperation

---

## **SEGMENT 5: :40–:50 | ARRIVAL AT STORAGE + PARTS 1 & 2 LOST**

### Narrative
Operator reaches storage, exhausted. Lightning strike illuminates. Searches desperately. Part 1 RIPPED BY WIND GUST. Part 2 DROPS AND SHATTERS on frozen ground. Two parts lost. Panic. Loss counter surges past $85,000.

### Visuals
- **Lightning at 0.5s:**
  - Close strike with jagged bolt (10 segments + branches)
  - White flash 35% opacity for 80ms
  - Screen shake 0.6
  - Thunder 45Hz sawtooth 2s + noise burst
- **Operator arrival (0–2s):** Exhausted walk to storage (x=70%)
- **Part 1 examination (2–5s):**
  - Hand reaches, picks up #8899aa colored part
  - Examines in darkness
  - At 4.8s: WIND GUST — part RIPPED from hands, flies right off-screen
  - Operator frustration animation (arms thrown up)
  - Audio: whoosh + crack
  - Screen shake 0.5
  - Loss flash: -$10,000
- **Part 2 examination (5.5–8s):**
  - Reaches for #99887a part (Coupling B)
  - Part covered in ice, slippery
  - At 7.5s: Part SLIPS from numb fingers, CRASHES to frozen ground
  - Shatter particle burst (15 pieces, impact sounds 3000Hz+1500Hz+800Hz)
  - Red flash 150ms
  - Alert popup: "PART DESTROYED — Coupling B shattered on impact!"
  - Loss flash: -$15,000
- **Operator panic (8–10s):** Eyes wide, sweat drops visible, maximum struggle factor

### Audio
- **Wind:** Howling 8% volume
- **Rain:** Heavy patter 6%
- **0.5s:** Thunder loud
- **4.8s:** Whoosh, crack, grunt
- **7.5s:** Shatter (cascading frequencies), crash (80Hz sawtooth 0.4s)
- **8.5s:** Operator frustrated sigh

### Key Metrics
- **Downtime timer:** ~16:00 → ~22:00 in-world
- **Loss counter:** $55,000 → $90,000 (spikes at loss events)
- **Parts status:**
  - Part 1 (Valve A): BLOWN AWAY
  - Part 2 (Coupling B): BROKEN
  - Part 3: Still in storage (unchecked)
  - Part 4: Still in storage (unchecked)

### Emotional Arc
Exhausted relief → desperate searching → horror of loss → panic

---

## **SEGMENT 6: :50–1:00 | PARTS 3 & 4 + FROZEN PART STRUGGLE**

### Narrative
Part 3: Wrong specification — useless. ONE PART LEFT. Part 4 (Impeller X) is encased in ICE. Operator spends agonizing seconds chipping ice with numb fingers. Ice cracking sounds. Finally breaks free. But now comes the worst: getting back through FULL-FURY blizzard. Loss counter passes $110,000.

### Visuals
- **Weather escalation:**
  - Rain rate: 18 → 20+
  - Snow rate: 6 → 8 (full blizzard)
  - Wind speed: 5.5 → 6.5
  - Temperature: -28°C → -30°C
  - Wind speed: 90 → 100 km/h
  - Darkness: 0.35 → 0.50
- **Part 3 examination (0–3s):**
  - Reaches, picks up #7a8899 part (Flange C)
  - Examines in darkness, turning it
  - At 2.2s: REALIZATION — wrong spec
  - Head shake, puts part back
  - Audio: installFail buzz (deflating sound)
  - Loss flash: -$10,000
- **Part 4 frozen struggle (3–8s):**
  - Found correct part (blue #00bbee Impeller X)
  - BUT IT'S FROZEN SOLID TO SHELF
  - Operator pulls/twists in desperation
  - Screen shake 0.15 every pull attempt
  - Ice crack sounds every 1.5s
  - **Progress display appears:**
    - 3.5s: 15%
    - 4.5s: 35%
    - 5.5s: 60%
    - 6.5s: 80%
    - 7.0s: 95%
    - 7.5s: 100% — FREE!
  - Part breaks loose at 7.5s with dual crack sounds + relieved grunt
  - Operator briefly inspects freed part, green flash
  - Struggle factor increases (2.0 → 2.5)
- **Realization (8–10s):** Operator turns left to look at equipment 200m away through blizzard, expression shifts to DREAD

### Audio
- **Continuous:** Howling wind 8% (increasing), rain 6%, dark music building
- **Cracking sounds:** 3.5s, 4.5s, 5.5s, 6.5s, 7.5s (escalating intensity)
- **2.5s:** installFail buzz
- **7.5s:** Loud crack + relieved grunt

### Key Metrics
- **Downtime timer:** ~22:00 → ~30:00 in-world
- **Loss counter:** $90,000 → $110,000
- **Parts status:**
  - Part 1: BLOWN AWAY ✗
  - Part 2: SHATTERED ✗
  - Part 3: WRONG SPEC ✗
  - Part 4: ✓ IN HAND — CORRECT PART
- **Complication:** "Correct part frozen to shelf!" (cleared)
- **New complication:** "Must return through peak blizzard!"

### Emotional Arc
Frustration → desperation → determination → dread of return journey

---

## **SEGMENT 7: 1:00–1:10 | NIGHTMARE WALK BACK + CASCADE EQUIPMENT FAILURE**

### Narrative
MOST INTENSE SEGMENT. Full blizzard fury — 120+ km/h winds. Operator fights back to equipment carrying precious part. Lightning strikes. They stumble badly. Meanwhile, equipment suffers SECONDARY CASCADE DAMAGE — smoke pours, new cracks appear. Alert screams "CASCADE FAILURE." Loss counter rockets past $150,000.

### Visuals
- **Weather at maximum fury:**
  - Rain rate: 20+ (torrential — streaked across screen)
  - Snow rate: 9+ (full blizzard)
  - Wind speed: 8+ (hurricane force — 120+ km/h)
  - Temperature: -35°C → -38°C
  - Fog opacity: 0.25+
  - Wind streaks: 2–3 per second, 500+px/s horizontal particles
  - Frost overlay opacity: 0.5 → 0.65 (claustrophobic edges)
- **Camera:** Unstable, continuous 0.3 intensity shake from wind force
  - 0–3s: Tracking operator moving left
  - 3.5s: Snap shake 1.5 (stumble moment — HEAVY)
  - 5s: Snap shake 1.2 (lightning)
  - 6–8s: Cut to equipment in distance (zoom 1.15), show damage
  - 8–10s: Wide shot, show both operator struggling and equipment smoking
- **Operator (movement 68% → 42%):**
  - Struggle factor: 2.5 → 3.0 (maximum)
  - Shiver: 1.5 → 2.0
  - Windlean: Body tilted 12–15° into wind
  - Walk animation: 50% slower, very short strides
  - **Stumble at 3.5s:**
    - 1.5s duration wobble (12px vertical)
    - Screen shake 1.5
    - Audio: crash/thud, grunt, whoosh
    - Complication: "Operator nearly FELL – risk of part damage"
  - **Flinch at 5s:** Ducks head, hunches shoulders from nearby lightning
  - **Cold breath:** Large clouds every 1.5s, drifting fast with wind
  - Expression: Panicked (wide 2.5px eyes, open mouth, sweat drops)
- **Lightning at 5s:**
  - Close strike with 12 segments + 3 branches
  - Zigging/zagging down from cloud to ground
  - White flash 80ms at 35% opacity
  - Thunder: IMMEDIATE (close strike), no delay, LOUD
  - Screen shake 1.2
- **Equipment damage cascade (6s onward):**
  - Camera cuts to show equipment close-up
  - **Crack level:** Increases from 1 → 3 (maximum)
  - New cracks appear:
    - Line 2: 75% top → 65% at 30% → 72% at 50%
    - Line 3: 10% at 50% → 25% at 65% → 12% at 85%
    - Line 4: 50% at 60% → 60% at 75% → 45% at 90%
  - **Smoke:** HEAVY — 1.5 particles/sec, larger clouds
  - **Sparks:** Electrical arcs — 3 per 0.3s
  - **Status:** Error display flashing aggressively
  - **Gear:** Continuous 0.4–0.7 shake from internal damage + wind
  - Audio: Creaking metal (120Hz sawtooth 0.6s + 90Hz triangle 0.8s)
  - **Alert popup at 6.5s:**
    - Title: "⚠ CASCADE FAILURE"
    - Subtitle: "Extended downtime causing corrosion & thermal damage!"
    - Red background, white text, border glow
    - Duration: 3.5s
    - Animation: Scale pop with bounce

### Audio
- **Wind:** Deafening howl 14% volume (continuous)
- **Rain:** Hammering patter 8%
- **Music:** Maximum tension — dissonant strings, low brass hits on complications
- **3.5s:** Crash, grunt, whoosh (stumble)
- **5s:** Thunder LOUD (immediate)
- **6.5s:** Creak (metal stress), alarm beep
- **8.5s:** Thunder distant (0.8s delay)

### Key Metrics
- **Downtime timer:** ~32:00 → ~55:00 in-world (time acceleration intensifies)
- **Loss counter:** $115,000 → $165,000
  - Loss flashes: -$15,000 @ 3.5s, -$20,000 @ 6.5s
- **Complications accumulate:**
  - "Storm at MAXIMUM intensity"
  - "Operator nearly FELL"
  - "SECONDARY EQUIPMENT DAMAGE detected!"

### Emotional Arc
Desperate struggle → catastrophic realization → equipment horror → maximum tension

---

## **SEGMENT 8: 1:10–1:20 | FAILED FIRST INSTALL + BARELY SUCCEED + AFTERMATH**

### Narrative
Operator reaches equipment, completely battered. First installation attempt FAILS — hands too frozen, part misaligned. Second attempt barely succeeds. Equipment limps to 60% capacity. Then devastating damage assessment: line items scroll, totaling $355,000+. Operator defeated in raging storm.

### Visuals
- **Operator arrival (0–1.5s):**
  - Position: Arriving at x=30% from left
  - Pose: Walk_exhausted
  - Struggle: 2.5
  - Exhaustion: 1.0
  - Shiver: 2.0
  - Expression: Desperate exhaustion
  - Holding Part 4 (cyan glow)
- **Installation attempt 1 (1.5–3.5s):**
  - Pose: Install (arms forward, working on equipment front panel)
  - Part released at 1.5s
  - **FAILURE at 3s:**
    - Audio: installFail buzz, grunt
    - Screen shake 0.3
    - Red flash 100ms
    - Alert popup: "INSTALLATION FAILED — Part slipped – misalignment!"
    - Duration: 2.5s
    - Complication: "First installation attempt FAILED!"
    - Operator reacts: Head drops, arms shake in frustration
    - Loss flash: -$15,000 (now $130,000)
- **Installation attempt 2 (3.5–5.5s):**
  - Pose: Install (trying again with last ounce of strength)
  - **SUCCESS at 5s (barely):**
    - Audio: Weak clang, sad boop (250Hz 0.8s — deflated sound)
    - **Equipment status: 60% CAPACITY** (not 100%)
    - Display shows compromise
    - Gear rotates with stuttering (sin wave speed variation 0.2–0.4 rad/s)
    - Cracks remain at level 3
    - Smoke continues (0.5/sec)
    - Sparks occasional (0.3/sec)
    - **Capacity bar appears:** Red bar showing "60% CAPACITY"
- **Aftermath (5.5–10s):**
  - Operator pose: Defeated
  - Arms hanging limply at sides
  - Head bowed
  - Expression: Defeat — no smile, eyes downcast
  - Struggle: 2.0
  - Exhaustion: 1.0
  - Standing motionless in rain, looking at damage
- **Damage Assessment sequence (6–9.2s):**
  - Appears one by one with impact sounds
  - **6.5s:** "Lost production (70 min): -$150,000"
    - Loss jumps to $220,000
    - Loss flash: -$150,000
    - Complication: "Lost production: $150,000"
    - Audio: Low impact tone
  - **7.5s:** "Secondary equipment damage: -$100,000"
    - Loss jumps to $300,000
    - Loss flash: -$100,000
    - Complication: "Secondary damage: $100,000"
    - Audio: Deeper impact tone
  - **8.5s:** "Storm exposure corrosion: -$50,000"
    - Loss jumps to $340,000
    - Loss flash: -$50,000
    - Complication: "Corrosion damage: $50,000"
  - **9.2s:** "Broken spare parts: -$15,000"
    - Loss jumps to $355,000
    - Loss flash: -$15,000
    - Complication: "Broken parts: $15,000"
    - **Alert popup:**
      - Title: "TOTAL LOSSES"
      - Subtitle: "$355,000+"
      - Style: LARGE red alert
      - Duration: 5 seconds
      - Animation: Dramatic scale from 0.5 → 1.0

### Audio
- **Continuous:** Wind (now subsiding slightly, 6% volume), rain decreasing
- **5s:** Sad boop (deflating)
- **Damage items:** Low impact tones increasing in bass weight
- **Music:** Reaches emotional nadir — single sustained minor chord, fading

### Key Metrics
- **Downtime timer:** FREEZES at 70:00 in-world
- **Display:** 01:10 real time
- **Timer color:** Red with ✗ symbol
- **Loss counter final:** $355,000+
- **Equipment capacity:** 60% (damaged, compromised)
- **Parts lost:** 2 of 4 destroyed, 1 wrong spec, 1 barely working

### Emotional Arc
Final struggle → failure of first attempt → barely succeed → destruction realization → complete defeat

---

## **SEGMENT 9: 1:20–1:30 | COMPARISON + CALL TO ACTION**

### Narrative
Fade to black. Side-by-side comparison: Scenario A vs Scenario B. Every metric contrasted in green vs red. $0 vs $355,000+. 15 seconds vs 70+ minutes. Devastating contrast. Final CTA with AddManuChain branding, tagline, and call to action.

### Visuals
- **Transition (0–1.5s):**
  - Fade all elements to black (HUD, messages, weather, scene)
  - All sound fades to silence over 1s
- **Comparison screen (1.5–6.5s):**
  - Background: Radial gradient from #0a1628 (center) to black (edges)
  - Fade in: 0.8s
  - **Title:** "One Decision. Two Outcomes." (38px weight 800)
    - Animation: Fade + slight scale 0.95 → 1.0
  - **Two cards layout:** 45% width each, 30px gap, centered
  - **Left card — SCENARIO A (success):**
    - Style: Gradient rgba(0,200,100,0.1) to rgba(13,217,255,0.06)
    - Border: 1px solid rgba(0,255,150,0.2)
    - Header: "⚡ SCENARIO A — On-Demand Parts"
    - Metrics (each row fades in 0.2s staggered):
      - ⏱ Downtime: **15 seconds** (green #00ff66)
      - 💰 Production Loss: **$0** (green)
      - 📦 Inventory: **Digital (KB)** (green)
      - 🛡 Weather Risk: **None** (green)
      - 🔧 Equipment: **100%** (green)
      - ✅ Result: **MISSION SUCCESS** (green)
  - **Right card — SCENARIO B (failure):**
    - Style: Gradient rgba(200,0,0,0.1) to rgba(100,0,0,0.06)
    - Border: 1px solid rgba(255,50,50,0.2)
    - Header: "📦 SCENARIO B — Traditional Inventory"
    - Metrics (same stagger timing):
      - ⏱ Downtime: **70+ minutes** (red #ff4444)
      - 💰 Production Loss: **$355,000+** (red)
      - 📦 Inventory: **Physical Warehouse** (red)
      - ⚠️ Weather Risk: **Critical** (red)
      - 🔧 Equipment: **60% (Damaged)** (red)
      - ❌ Result: **CATASTROPHIC FAILURE** (red)
  - **Bottom message (at 4s):**
    - Text: "EVERY DELAY IN REMOTE OPERATIONS = CATASTROPHIC LOSS"
    - Font: 20px weight 700
    - Color: #ff9966
    - Animation: Fade in, pulse glow
  - **Comparison visible:** 1.5–6.5s (5 seconds total)
- **CTA screen (6.5–10s):**
  - Transition: Comparison fades out, CTA fades in over 0.8s
  - **Headline:** "In remote operations, every second counts."
    - Font: 42px weight 800
    - Color: White
    - Line height: 1.2
    - Position: Upper center
  - **Subtext:**
    - "From $355,000+ in losses to $0 downtime."
    - "Digital parts. On-demand printing. Mission-critical reliability."
    - Font: 17px
    - Color: #99aabb
    - Highlights in cyan (#0dd9ff):
      - "$355,000+ in losses"
      - "$0 downtime"
  - **Brand name:** "AddManuChain"
    - Font: 28px weight 900, letter-spacing 3px
    - Style: Gradient cyan-to-green (background-clip text)
    - Animation: Subtle glow pulse
  - **Contact line:** "Let's talk about your remote operations."
    - Font: 14px
    - Color: #6699bb
  - **Replay button:** "↻ REPLAY DEMO"
    - Style: Outlined, white text, semi-transparent background
    - Hover effect: Cyan border glow

### Audio
- **0–1.5s:** All sound fades to silence
- **1.5s:** Subtle ambient pad fades in (C major, hopeful)
- **3s:** Soft piano note — single chord
- **6.5s onward:** Gentle ascending synth (resolve, hope, clarity)
- **Overall arc:** Tension → silence → resolution

### Key Messaging
| Metric | Scenario A | Scenario B |
|--------|-----------|-----------|
| **Downtime** | 15 seconds | 70+ minutes |
| **Loss** | $0 | $355,000+ |
| **Inventory** | Digital | Physical Warehouse |
| **Weather Risk** | None | Critical |
| **Equipment** | 100% | 60% Damaged |
| **Outcome** | ✅ Success | ❌ Catastrophic |

### Emotional Arc
Tension release → silent clarity → devastating comparison → hope & resolution

---

## **OVERALL 90-SECOND ARC**

### Timeline Summary
| Segment | Time | Scenario | Key Event | Loss |
|---------|------|----------|-----------|------|
| 1 | :00–:10 | A | Failure strikes | $0 |
| 2 | :10–:20 | A | Digital part retrieval & victory | $0 |
| 3 | :20–:30 | B | Setup & failure (no digital) | $10k–$15k |
| 4 | :30–:40 | B | Desperate walk, weather worsens | $15k–$45k |
| 5 | :40–:50 | B | Storage, 2 parts lost | $55k–$90k |
| 6 | :50–1:00 | B | Frozen part, scary return | $90k–$110k |
| 7 | 1:00–1:10 | B | Nightmare blizzard + cascade failure | $115k–$165k |
| 8 | 1:10–1:20 | B | Failed install, equipment damaged, assessment | $90k–$355k |
| 9 | 1:20–1:30 | A vs B | Comparison & CTA | — |

### Emotional Journey
1. **:00–:10** — Calm confidence → Shock
2. **:10–:20** — Triumph & vindication
3. **:20–:30** — Dread begins (reset)
4. **:30–:40** — Growing desperation
5. **:40–:50** — Loss & panic
6. **:50–1:00** — Frozen desperation
7. **1:00–1:10** — Maximum terror & horror
8. **1:10–1:20** — Failure & devastation
9. **1:20–1:30** — Clarity, contrast, resolution & hope

### Core Message
**Digital on-demand manufacturing eliminates the catastrophic cost of downtime in remote, mission-critical operations.**

- Scenario A: 15 seconds, $0 loss → Success
- Scenario B: 70+ minutes, $355,000+ loss → Failure
- **The difference?** Digital inventory via AddManuChain.

---

## **PRODUCTION NOTES**

### Technology Stack
- **Engine:** Canvas 2D or WebGL
- **Rendering:** 1920×1080 @ 30fps (16:9 aspect ratio)
- **Font:** Segoe UI (primary), JetBrains Mono (code/numbers)
- **Anti-aliasing:** Enabled
- **Motion blur:** 0.15 global

### Asset Requirements
- **Color palette:** Predefined (cyan #0dd9ff, green #00ff66, red #ff3333, grays)
- **Particle system:** Rain, snow, smoke, sparks, confetti, cold breath
- **Audio:** Ambient synth pads (C major / D minor), wind/rain loops, UI tones, synthesized thunder/alarms
- **Typography:** High contrast white/cyan text for HUD, story messages

### Key Visual Moments
1. Equipment startup (calm)
2. Catastrophic failure (shake/alarm)
3. Pocket glow reveal (hint)
4. Part floating with trail
5. Installation snap (spark explosion)
6. Confetti victory
7. Fade to darkness (transition)
8. Storage building arrival
9. Wind gust part loss
10. Shatter impact
11. Frozen part struggle
12. Lightning strike
13. Cascade damage to equipment
14. Failed installation
15. Damage assessment scroll
16. Side-by-side comparison
17. AddManuChain CTA

### Performance Optimization
- Particle pooling for rain/snow/smoke
- Canvas clipping for weather effects
- Pre-rendered static backgrounds
- Lazy-loaded audio (Web Audio API oscillators generated on-the-fly)

---

**Total Duration:** 90 seconds  
**Total segments:** 9 × 10 seconds  
**Emotional peaks:** :20 (triumph), 1:10 (horror), 1:30 (resolution)
