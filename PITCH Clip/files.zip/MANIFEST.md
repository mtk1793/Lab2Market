# AddManuChain 90-Second Pitch Clip – Complete File Manifest

## 📦 Deliverables Summary

**Total Files:** 13  
**Total Size:** ~192 KB (well-compressed JSON)  
**Format:** 100% JSON + Markdown (human-readable)  
**Status:** ✅ Production Ready  

---

## 📄 Files Overview

### Core JSON Segment Files (9 files)

| # | File | Timespan | Size | Content |
|---|------|----------|------|---------|
| 1 | `segment_001_00to10.json` | 0:00–0:10 | 16 KB | Scenario A setup + catastrophic failure |
| 2 | `segment_002_10to20.json` | 0:10–0:20 | 14 KB | Part retrieval + perfect installation + victory |
| 3 | `segment_003_20to30.json` | 0:20–0:30 | 14 KB | Transition to Scenario B + setup + failure |
| 4 | `segment_004_30to40.json` | 0:30–0:40 | 12 KB | Storm intensification + desperate walk begins |
| 5 | `segment_005_40to50.json` | 0:40–0:50 | 14 KB | Storage arrival + two critical parts lost |
| 6 | `segment_006_50to60.json` | 0:50–1:00 | 13 KB | Frozen part struggle + dread of return |
| 7 | `segment_007_008_009_60to90.json` | 1:00–1:30 | 24 KB | Nightmare walk + cascade failure + comparison + CTA |

**Subtotal Segment Files:** 24 + 14 + 14 + 12 + 14 + 13 + 24 = **115 KB**

---

### Index & Reference Files (4 files)

| File | Type | Size | Purpose |
|------|------|------|---------|
| `segment_master_index.json` | JSON | 12 KB | Master index, global settings, color palette, audio design |
| `JSON_IMPLEMENTATION_GUIDE.json` | JSON | 20 KB | Technical developer guide with rendering workflow |
| `README.md` | Markdown | 9.6 KB | Quick start guide and file structure overview |
| `SEGMENT_STRUCTURE_BREAKDOWN.md` | Markdown | 30 KB | Detailed timeline breakdown with narrative by segment |

**Subtotal Reference Files:** 12 + 20 + 9.6 + 30 = **71.6 KB**

---

## 🗂️ How to Use These Files

### For Project Managers / Production Teams
1. **Start here:** `README.md` (quick overview)
2. **Review:** `SEGMENT_STRUCTURE_BREAKDOWN.md` (detailed narrative)
3. **Reference:** `segment_master_index.json` (global settings)

**Time to understand:** ~15 minutes

---

### For Animation / Design Teams
1. **Start here:** `SEGMENT_STRUCTURE_BREAKDOWN.md` (visual timeline)
2. **Load:** Individual segment files (segment_001 → segment_007_008_009)
3. **Reference:** `AddManuChain_Pitch_Clip_10sec_Breakdown.md` (technical specifications)

**Time to understand:** ~30 minutes per segment

---

### For Developers / Rendering Engineers
1. **Start here:** `JSON_IMPLEMENTATION_GUIDE.json` (technical specifications)
2. **Load:** `segment_master_index.json` (global initialization)
3. **Parse:** Each segment file sequentially (001 → 009)
4. **Implement:** Following renderingWorkflow in guide

**Time to understand:** ~1 hour to get started

---

## 📋 File Dependencies & Load Order

```
segment_master_index.json
  ↓ (loads global settings)
  ├─ segment_001_00to10.json (0:00)
  ├─ segment_002_10to20.json (0:10)
  ├─ segment_003_20to30.json (0:20)
  ├─ segment_004_30to40.json (0:30)
  ├─ segment_005_40to50.json (0:40)
  ├─ segment_006_50to60.json (0:50)
  └─ segment_007_008_009_60to90.json (1:00)
      ├─ Segment 7: 1:00–1:10
      ├─ Segment 8: 1:10–1:20
      └─ Segment 9: 1:20–1:30
```

---

## 🎬 Content Breakdown by Segment

| Seg | Time | Scenario | Event | Duration | Loss |
|-----|------|----------|-------|----------|------|
| 1 | 0:00–0:10 | A | Setup + failure | 10s | $0 |
| 2 | 0:10–0:20 | A | Victory | 10s | $0 |
| **3** | **0:20–0:30** | **B** | **Transition + setup** | **10s** | **$10k** |
| 4 | 0:30–0:40 | B | Storm + walk | 10s | $45k |
| 5 | 0:40–0:50 | B | Parts lost | 10s | $90k |
| 6 | 0:50–1:00 | B | Frozen part | 10s | $110k |
| 7 | 1:00–1:10 | B | Nightmare walk | 10s | $165k |
| 8 | 1:10–1:20 | B | Failed install | 10s | $355k |
| 9 | 1:20–1:30 | CTA | Comparison | 10s | — |

---

## 🔍 Key Sections in Each Segment File

Every segment JSON includes:

```json
{
  "id": "segment identifier (1-9)",
  "label": "human-readable name",
  "timeRange": "MM:SS – MM:SS",
  "duration": 10,
  "narrative": "story description",
  
  "background": {...},     // Sky, clouds, mountains, fog, snow, lighting
  "camera": {...},         // Position, zoom, movement, easing, timing
  "operator": {...},       // Position, pose, expression, animation, clothing
  "equipment": {...},      // Body, gear, screen, lights, cracks, smoke, sparks
  "weather": {...},        // Rain, wind, temperature, fog, frost overlay
  "audio": {...},          // Music (key, mood, volume), SFX (frequency, duration)
  "hud": {...},            // Timer, loss counter, temperature, wind speed
  "textOverlays": {...},   // Main messages, sub-messages (font, color, animation)
  "screenEffects": {...},  // Shake, flash, glow, frost, transitions
  "transitionToNextSegment": {...} // Carryover state for seamless continuation
}
```

---

## 🎨 Global Design Constants

### Color Palette
- **Scenario A (Success):** Cyan #0dd9ff, Green #00ff66
- **Scenario B (Failure):** Red #ff3333, Orange #ffaa00
- **Equipment:** Dark Blue #1c4466
- **Text:** White #ffffff, Light Gray #cccccc
- **Sky Clear:** #5599cc, Sky Storm: #0a0a18

### Audio Design
- **Scenario A:** C Major (peaceful → triumphant)
- **Scenario B:** D Minor (ominous → desperate)
- **Music Volume:** 15–20% (A), 10–18% (B)
- **Wind:** 4–14% volume, 400Hz lowpass filter
- **Rain:** Noise at varying rates (4–20/sec particles)

### Render Specifications
- **Resolution:** 1920×1080 (16:9)
- **Frame Rate:** 30 fps
- **Total Frames:** 2700
- **Fonts:** Segoe UI (primary), JetBrains Mono (code)
- **Anti-alias:** Enabled | Motion Blur: 0.15

---

## ✅ Quality Checklist

- ✓ All 9 segments present and complete
- ✓ Seamless 1-second overlaps between segments
- ✓ Consistent camera positioning and movement
- ✓ Equipment state carries forward logically
- ✓ Operator poses transition smoothly
- ✓ Weather intensity aligns with timeline
- ✓ HUD counters continue accurately
- ✓ Audio music/SFX layers properly
- ✓ Screen effects fade appropriately
- ✓ All timestamps documented to 0.1s precision
- ✓ All animations specify easing functions
- ✓ All colors defined as hex or rgba
- ✓ All positions defined as screen percentages

---

## 🚀 Getting Started (TL;DR)

### For Quick Overview (5 minutes)
→ Read `README.md`

### For Understanding the Story (15 minutes)
→ Read `AddManuChain_Pitch_Clip_10sec_Breakdown.md`

### For Visual Timeline (20 minutes)
→ Read `SEGMENT_STRUCTURE_BREAKDOWN.md`

### For Implementation (1+ hours)
→ Read `JSON_IMPLEMENTATION_GUIDE.json`  
→ Load `segment_master_index.json`  
→ Parse individual segment files

---

## 📊 Statistics

| Metric | Value |
|--------|-------|
| Total Duration | 90 seconds |
| Total Frames | 2700 (30 fps) |
| Number of Segments | 9 |
| Overlap Points | 8 |
| Scenario A Duration | 20 seconds |
| Scenario B Duration | 60 seconds |
| Catastrophic Loss Demonstrated | $355,000+ |
| Perfect Scenario Savings | $355,000+ |
| Peak Downtime Difference | 70+ minutes vs 15 seconds |
| Emotional Low Point | Segment 8 (~75 seconds) |
| Emotional Peak (Victory) | Segment 2 (~15 seconds) |
| Emotional Peak (Hope) | Segment 9 (~86 seconds) |

---

## 🎯 Narrative Arc

```
Confidence ─→ Shock ─→ Triumph      (Scenario A: 0–20s)
     ↓
   Reset ─→ Dread ─→ Desperate ─→ Horror ─→ Devastation (Scenario B: 20–80s)
     ↓
   Clarity ─→ Contrast ─→ Hope & Resolution (CTA: 80–90s)
```

---

## 📝 File Sizes (Detailed)

```
segment_001_00to10.json ..................... 16 KB
segment_002_10to20.json ..................... 14 KB
segment_003_20to30.json ..................... 14 KB
segment_004_30to40.json ..................... 12 KB
segment_005_40to50.json ..................... 14 KB
segment_006_50to60.json ..................... 13 KB
segment_007_008_009_60to90.json ............. 24 KB
segment_master_index.json ................... 12 KB
JSON_IMPLEMENTATION_GUIDE.json .............. 20 KB
README.md .................................. 9.6 KB
AddManuChain_Pitch_Clip_10sec_Breakdown.md .. 24 KB
SEGMENT_STRUCTURE_BREAKDOWN.md .............. 30 KB
                                        ─────────
TOTAL .................................... 192 KB
```

---

## 🔗 Cross-References

**Within Segment Files:**
- Every segment specifies `transitionToNextSegment` with carryover state
- Overlap pattern: segment N's 9.0–10.0s matches segment N+1's 0.0s

**Within Reference Files:**
- `README.md` → Links to other guides
- `SEGMENT_STRUCTURE_BREAKDOWN.md` → Detailed breakdown of every segment
- `JSON_IMPLEMENTATION_GUIDE.json` → Technical specs for developers
- `segment_master_index.json` → Global settings used by all segments

---

## ⚙️ Rendering Workflow (High Level)

```
1. Load segment_master_index.json
   ↓
2. Initialize canvas (1920×1080 @ 30fps)
   ↓
3. For each segment (1-9):
   a. Load segment JSON file
   b. Parse timeline events
   c. Create frame-by-frame schedule
   d. Render frame by frame
   e. Handle transitions at boundaries
   ↓
4. Play audio (Web Audio API)
   ↓
5. Output as video (canvas → MP4) or stream live
```

---

## 🎓 Learning Path

**Level 1: Story Understanding**
- `README.md` (5 min)
- `AddManuChain_Pitch_Clip_10sec_Breakdown.md` (20 min)

**Level 2: Visual Concepts**
- `SEGMENT_STRUCTURE_BREAKDOWN.md` (30 min)
- `segment_master_index.json` (15 min)

**Level 3: Technical Implementation**
- `JSON_IMPLEMENTATION_GUIDE.json` (45 min)
- Individual segment files (30 min each × 9 = 4+ hours)

**Total Time to Production:** ~6 hours (with prior animation/development experience)

---

## 📞 Support Resources

For questions about:
- **Story/strategy:** Consult project leads
- **Animation specs:** Refer to SEGMENT_STRUCTURE_BREAKDOWN.md
- **Technical implementation:** Consult JSON_IMPLEMENTATION_GUIDE.json
- **Quick answers:** Refer to README.md

---

## 🏁 Final Checklist Before Production

- [ ] All 13 files downloaded and verified
- [ ] JSON files validated for syntax errors
- [ ] Team members assigned to each file type (narrative, animation, code)
- [ ] Target render engine selected (Canvas 2D, WebGL, etc.)
- [ ] Audio assets verified (synthesized via Web Audio API)
- [ ] Timeline and milestones created based on 9 segments
- [ ] Color palette imported into design tools
- [ ] Font files obtained (Segoe UI, JetBrains Mono)
- [ ] Test render performed on 1 segment
- [ ] Full 90-second render completed
- [ ] Quality checklist items verified (smooth transitions, timing, audio sync)

---

**Version:** 1.0 | **Status:** ✅ Production Ready | **Last Updated:** March 2026

---

*For any questions or clarifications, refer to the specific guide file or contact the project team.*
