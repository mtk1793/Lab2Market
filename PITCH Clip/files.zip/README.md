# AddManuChain 90-Second Pitch Clip – JSON Implementation Files

## Overview

This is a complete JSON specification for a 90-second animated pitch clip comparing two scenarios:
- **Scenario A (0–20s):** On-demand digital spare parts → 15 seconds downtime, $0 loss
- **Scenario B (20–80s):** Traditional physical inventory → 70+ minutes downtime, $355,000+ loss
- **Comparison & CTA (80–90s):** Side-by-side metrics and call to action

Each segment is divided into **10-second chunks** with seamless **1-second overlaps** for continuity.

---

## File Structure

### Segment Files (Individual 10-Second Chunks)
- **`segment_001_00to10.json`** – Scenario A: Calm operations + sudden failure
- **`segment_002_10to20.json`** – Scenario A: Hero retrieval + perfect installation + victory
- **`segment_003_20to30.json`** – Transition + Scenario B: Setup + equipment failure
- **`segment_004_30to40.json`** – Scenario B: Storm hits + desperate walk begins
- **`segment_005_40to50.json`** – Scenario B: Arrival at storage + parts 1 & 2 lost
- **`segment_006_50to60.json`** – Scenario B: Frozen part struggle + realization
- **`segment_007_008_009_60to90.json`** – Segments 7, 8, 9 (nightmare walk, cascade failure, comparison)

### Index & Reference Files
- **`segment_master_index.json`** – Central index with global settings, color palette, audio design
- **`JSON_IMPLEMENTATION_GUIDE.json`** – Technical implementation guide for developers
- **`AddManuChain_Pitch_Clip_10sec_Breakdown.md`** – Human-readable narrative and visual breakdowns

---

## Quick Start

### For Production Teams
1. **Read first:** `AddManuChain_Pitch_Clip_10sec_Breakdown.md` (plain language summary)
2. **Review:** `segment_master_index.json` (global overview)
3. **Use:** Individual segment files as reference during production

### For Developers / Animation Engineers
1. **Read first:** `JSON_IMPLEMENTATION_GUIDE.json` (technical specifications)
2. **Load:** `segment_master_index.json` for global settings
3. **Loop:** Load each segment sequentially (001 → 009)
4. **Parse:** Extract camera, operator, equipment, audio, HUD, text, effects from each segment
5. **Render:** Follow the "renderingWorkflow" section in the implementation guide

---

## Key Features

### Seamless Transitions
- **1-second overlap** between segments (e.g., Segment 1 ends at 10s, Segment 2 starts at 0s global = 10s)
- `transitionToNextSegment` field specifies state carryover
- Operator position, equipment status, weather intensity all carry forward logically

### Comprehensive Data
Each segment includes:
- **Background** – Sky colors, clouds, mountains, fog, snow accumulation
- **Camera** – Position, zoom, movement (slow push, snap shake, pan), duration, easing
- **Equipment** – 3D model components (gear, display, lights, cracks, smoke, sparks)
- **Operator** – Position, pose, expression, animation, clothing (hard hat, jacket)
- **Weather** – Rain particles, wind speed, temperature, wind streaks, fog, frost overlay
- **Audio** – Music (key, tempo, mood, volume), SFX (frequency, waveform, duration)
- **HUD** – Timer, loss counter, temperature, wind speed displays
- **Text Overlays** – Main messages, sub-messages (font, color, position, animation)
- **Screen Effects** – Shake, flash, glow, frost creeping, lighting transitions

### Production Ready
- All colors defined as hex or rgba strings
- All positions defined as screen percentages (x%, y%)
- All timings defined in seconds (sub-frame precision)
- All durations defined in seconds with easing functions
- All audio specifications include frequency, waveform, volume

---

## Rendering Specifications

| Property | Value |
|----------|-------|
| **Resolution** | 1920×1080 (16:9) |
| **Frame Rate** | 30 fps |
| **Total Frames** | 2700 (90 seconds × 30) |
| **Color Space** | RGB/RGBA |
| **Font (Primary)** | Segoe UI, system-ui, sans-serif |
| **Font (Monospace)** | JetBrains Mono, Consolas, monospace |
| **Anti-aliasing** | Enabled |
| **Motion Blur** | 0.15 (subtle) |

---

## JSON Data Structure (Simplified)

```json
{
  "segment": {
    "id": 1,
    "label": "SEGMENT NAME",
    "timeRange": "HH:MM – HH:MM",
    "duration": 10,
    "narrative": "Story description",
    "background": { "type": "...", "properties": {...} },
    "camera": { "timestamp": {...} },
    "operator": { "position": {...}, "timeline": {...} },
    "equipment": { "position": {...}, "components": {...} },
    "weather": { "rain": {...}, "wind": {...}, "temperature": {...} },
    "audio": { "timeRange": {...} },
    "hud": { "timer": {...}, "lossCounter": {...} },
    "textOverlays": { "timeRange": {...} },
    "screenEffects": { "effect": {...} },
    "complications": { "message": {...} }
  }
}
```

---

## Emotional Arc

| Seconds | Scenario | Emotion | Key Event |
|---------|----------|---------|-----------|
| 0–10 | A | Confidence → Shock | Equipment fails, operator doesn't panic |
| 10–20 | A | Focused → Triumph | Part retrieves, installs perfectly, victory |
| 20–30 | Reset | Dread begins | Transition: "What if no digital inventory?" |
| 30–40 | B | Growing desperation | Storm intensifies, operator walks toward storage |
| 40–50 | B | Horror & panic | Two parts lost (blown away, shattered) |
| 50–60 | B | Determination → Dread | Frozen part freed, realizes difficulty of return |
| 60–70 | B | Maximum terror | Nightmare walk, lightning, cascade equipment damage |
| 70–80 | B | Failure & devastation | Installation fails first try, barely succeeds, $355k loss |
| 80–90 | Comparison | Clarity → Hope | Side-by-side comparison, AddManuChain CTA |

---

## Audio Design Summary

### Music by Phase
- **Scenario A (0–20s):** C major, peaceful → hopeful → triumphant (15–20% volume)
- **Scenario B (20–80s):** D minor, ominous → tension → dissonance → despair (10–18% volume)
- **Comparison & CTA (80–90s):** C major, resolve → clarity → hope (10–12% volume)

### Sound Effects
- **Alarm:** 800Hz square (Scenario A) vs 400Hz sawtooth (Scenario B)
- **Thunder:** Synthesized 45Hz or 55Hz sawtooth with noise
- **Wind:** Noise generator with 400Hz lowpass filter
- **Rain:** Noise at varying rates (4–20 particles/sec)

---

## Implementation Tips

1. **Load Master Index First**
   - Contains global color palette, audio design, font specs
   - Use for initialization and setup

2. **Parse Timeline Events**
   - Extract all timed events from camera, operator, equipment, audio
   - Create frame-by-frame animation schedule

3. **Render Order**
   - Background → Equipment → Operator → Particles → HUD → Text → Screen Effects

4. **Handle Overlaps**
   - At 9.0–10.0s of each segment, prepare carryover state
   - Begin next segment at 0.0s with matching state

5. **Optimize Performance**
   - Use particle pooling (200 pre-allocated objects)
   - Render static backgrounds to offscreen canvas
   - Use requestAnimationFrame for frame scheduling
   - Cache transforms with ctx.save() / ctx.restore()

---

## Output Options

| Format | Method | Use Case |
|--------|--------|----------|
| **PNG Sequence** | canvas.toBlob() every frame | Frame-by-frame editing |
| **MP4 Video** | Assemble PNG sequence in ffmpeg | Final deliverable |
| **Real-time WebGL** | Three.js or Babylon.js | Interactive demo |
| **SVG** | Limited (simple elements only) | Vector animations |

---

## Glossary

- **Segment:** 10-second chunk of animation
- **Frame:** Single rendered image (1/30th of a second at 30fps)
- **Keyframe:** Timed event (camera move, text overlay, SFX) within a segment
- **Timeline:** Collection of keyframes sorted by time
- **HUD:** Heads-up display (timer, loss counter, temperature, wind speed)
- **Particle:** Individual rain drop, snowflake, spark, smoke puff, confetti piece
- **Emitter:** System that generates particles at a specified rate
- **Screen Effect:** Full-screen visual effect (shake, flash, glow, frost overlay)
- **Easing:** Interpolation function for smooth animation (linear, ease-in-out, etc.)

---

## Quality Checklist

- ✓ All segments load without errors
- ✓ Seamless 1-second overlaps at boundaries
- ✓ Camera movement matches descriptions
- ✓ Operator poses transition logically
- ✓ Equipment damage progresses correctly
- ✓ HUD counters advance accurately
- ✓ Audio crossfades smoothly
- ✓ Particles render without lag
- ✓ Text overlays appear/disappear on time
- ✓ Screen effects visible and properly timed
- ✓ 30fps playback smooth at 1920×1080

---

## Contact & Support

For questions about:
- **Narrative & strategy:** Mahmoud Kiasari (AddManuChain founder)
- **Animation & production:** Animation/design team
- **Technical implementation:** Development team
- **Overall project:** Lab2Market (Mitacs), Dalhousie University

---

## Files Summary

| File | Type | Size | Purpose |
|------|------|------|---------|
| segment_001_00to10.json | JSON | ~15 KB | Segment 1 data |
| segment_002_10to20.json | JSON | ~14 KB | Segment 2 data |
| segment_003_20to30.json | JSON | ~16 KB | Segment 3 data |
| segment_004_30to40.json | JSON | ~15 KB | Segment 4 data |
| segment_005_40to50.json | JSON | ~17 KB | Segment 5 data |
| segment_006_50to60.json | JSON | ~14 KB | Segment 6 data |
| segment_007_008_009_60to90.json | JSON | ~25 KB | Segments 7, 8, 9 data |
| segment_master_index.json | JSON | ~10 KB | Global index & settings |
| JSON_IMPLEMENTATION_GUIDE.json | JSON | ~30 KB | Technical guide |
| AddManuChain_Pitch_Clip_10sec_Breakdown.md | Markdown | ~20 KB | Human-readable summary |

**Total:** ~176 KB (well-compressed JSON, easily manageable)

---

**Version:** 1.0  
**Created:** March 2026  
**Status:** Production Ready
